public class Gauss {

    public static void main(String[] args) {
        Matrix system = MatrixGetter.getMatrix();
        system.print();

        SystemSolver.solveSystem(system).printSolution();
    }
}
